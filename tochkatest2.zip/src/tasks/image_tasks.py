from io import BytesIO
from celery import shared_task
from PIL import Image
import boto3

s3_client = boto3.client(
    's3',
    endpoint_url='http://minio:9000',
    aws_access_key_id='minio_user',
    aws_secret_access_key='minio_password',
    region_name='us-east-1'
)

@shared_task(name="process_image_task")
def process_image_task(task_id, image_path, transformations):
    # Load the image from MinIO
    obj = s3_client.get_object(Bucket='images', Key=image_path)
    img = Image.open(BytesIO(obj['Body'].read()))

    # Apply transformations
    for transformation in transformations:
        if transformation == 'rotate':
            img = img.rotate(90)
        elif transformation == 'gray':
            img = img.convert('L')
        elif transformation == 'scale':
            img = img.resize((img.width // 2, img.height // 2))

    # Save the processed image back to MinIO
    buffer = BytesIO()
    img.save(buffer, format='JPEG')
    buffer.seek(0)
    output_path = f"processed/{task_id}.jpg"
    s3_client.put_object(Bucket='images', Key=output_path, Body=buffer)

    return output_path
