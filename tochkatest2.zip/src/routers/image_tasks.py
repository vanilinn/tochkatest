from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from src.celery_app import celery_app
from sqlalchemy.ext.asyncio import AsyncSession
from src.core.database import get_async_session
from src.models.models import ImageTask
from src.schemas.image_tasks import ImageTaskResponse
from src.cruds.cruds import image_crud
import uuid
import boto3

router = APIRouter()

s3_client = boto3.client(
    's3',
    endpoint_url='http://minio:9000',
    aws_access_key_id='minio_user',
    aws_secret_access_key='minio_password',
    region_name='us-east-1'
)


@router.post("/upload/", response_model=ImageTaskResponse)
async def upload_image(file: UploadFile = File(...), session: AsyncSession = Depends(get_async_session)):
    task_id = str(uuid.uuid4())
    image_path = f"original/{task_id}.jpg"

    s3_client.put_object(Bucket='images', Key=image_path, Body=await file.read())

    task = celery_app.send_task("src.tasks.image_tasks.process_image", args=[task_id, image_path, ['rotate', 'gray']])

    image_task = ImageTask(task_id=task.id, img_link=image_path)
    await image_crud.create(image_task, session)

    return ImageTaskResponse(task_id=task.id, status="Processing")


@router.get("/tasks/{task_id}/", response_model=ImageTaskResponse)
async def get_task_status(task_id: str, session: AsyncSession = Depends(get_async_session)):
    task = celery_app.AsyncResult(task_id)
    if task.state == 'FAILURE':
        raise HTTPException(status_code=404, detail="Task failed")

    image_task = await image_crud.get_by_attribute(session, task_id=task_id)
    if not image_task:
        raise HTTPException(status_code=404, detail="Task not found")

    return ImageTaskResponse(task_id=task_id, status=task.state,
                             result=task.result if task.state == "SUCCESS" else None)
