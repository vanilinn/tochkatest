from pydantic import BaseModel, Field
from typing import Optional

class ImageTaskResponse(BaseModel):
    task_id: str = Field(..., description="ID задачи в Celery")
    status: str = Field(..., description="Статус выполнения задачи")
    result: Optional[str] = Field(None, description="Результат обработки изображения (ссылка на обработанное изображение)")

    class Config:
        orm_mode = True
